/* RTLH Admin opening window: slow code streams, music notes, running squirrels,
   flying black phoenix and an auto-typed name. Visual only; it never touches Firebase or login logic.
   Add to admin.html just before </body>:  <script src="admin-intro.js"></script> */
(function () {
  const L = document.getElementById("loginScreen");
  if (!L) return;
  const NAME = "NIYIBIGIRA Theoneste";
  const still = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  const R = (a, b) => a + Math.random() * (b - a);
  const pick = a => a[Math.floor(Math.random() * a.length)];

  const st = document.createElement("style");
  st.textContent =
    ".speed-track{display:none!important}" +
    "#introCanvas{position:fixed;inset:0;width:100%;height:100%;z-index:0;pointer-events:none}" +
    ".login-card{position:relative;z-index:2}" +
    "#typedName{font:800 15px/1.4 ui-monospace,Consolas,'Courier New',monospace;letter-spacing:1.5px;color:#071a2b;min-height:24px;margin:-8px 0 16px;text-align:center}" +
    "#typedName .pr{color:#1ea765}" +
    "#typedName .caret{display:inline-block;width:8px;height:16px;background:#1685e5;margin-left:3px;vertical-align:-2px;animation:rtlhBlink 1s steps(1) infinite}" +
    "@keyframes rtlhBlink{50%{opacity:0}}";
  document.head.appendChild(st);

  /* ---------- auto-typed name ---------- */
  const brand = L.querySelector(".login-brand");
  if (brand) {
    const box = document.createElement("div");
    box.id = "typedName";
    box.innerHTML = '<span class="pr">&gt; </span><span id="typedText"></span><span class="caret"></span>';
    brand.appendChild(box);
    const out = box.querySelector("#typedText");
    let i = 0, dir = 1;
    const tick = () => {
      i += dir;
      out.textContent = NAME.slice(0, i);
      if (i >= NAME.length) { dir = -1; return setTimeout(tick, 2400); }
      if (i <= 0) { dir = 1; return setTimeout(tick, 600); }
      setTimeout(tick, dir > 0 ? 115 : 55);
    };
    if (still) out.textContent = NAME; else tick();
  }

  /* ---------- canvas ---------- */
  const cv = document.createElement("canvas");
  cv.id = "introCanvas";
  cv.setAttribute("aria-hidden", "true");
  L.insertBefore(cv, L.firstChild);
  const ctx = cv.getContext("2d");
  let W = 0, H = 0;
  function size() {
    const d = Math.min(window.devicePixelRatio || 1, 2);
    W = innerWidth; H = innerHeight;
    cv.width = W * d; cv.height = H * d;
    ctx.setTransform(d, 0, 0, d, 0, 0);
  }
  size();

  const SN = ["const hub = await getDocs(courses)", "if (user.role === 'admin') { grant() }", "0x7F3A9C21  0xDE41B0A7", "SELECT * FROM learners;",
    '{"uid":"a91f3c","role":"admin"}', "01010010 01010100 01001100 01001000", "for (i = 0; i < n; i++) learn(i)", "npm run build && firebase deploy",
    "U2FsdGVkX19rd2FuZGE=", "git commit -m 'rtlh'", "fetch('/classes').then(r => r.json())", "<div class=\"hub\"></div>",
    "def teach(x): return x * 2", "SHA256:9b1c04e7d2a8", "async function enroll() {}", "ttl=64 time=12ms", "-1.9441, 30.0619", "0xFF 0x00 0xA3 0x5C",
    "#!/bin/bash", "ERR_NULL_PTR 0x0000", "while (true) { listen() }", "kigali://node/07"];
  const COL = ["80,200,255", "120,255,170", "246,201,40", "190,170,255"];
  const NOTES = ["♪", "♫", "♬", "♩", "♭", "♯", "🎶"];

  const nCode = W < 600 ? 14 : 26;
  const codes = Array.from({ length: nCode }, (_, k) => {
    const m = k % 3, s = pick([-1, 1]);
    const o = { t: pick(SN), x: R(0, W), y: R(20, H), col: COL[k % COL.length], a: R(0.28, 0.55), f: Math.round(R(11, 14)) + "px ui-monospace,Consolas,monospace", w: 200 };
    if (m === 0) { o.vx = s * R(18, 38); o.vy = R(-3, 3); }
    else if (m === 1) { o.vx = R(-3, 3); o.vy = s * R(14, 28); }
    else { o.vx = s * R(14, 28); o.vy = pick([-1, 1]) * R(10, 20); }
    ctx.font = o.f; o.w = ctx.measureText(o.t).width;
    return o;
  });
  const notes = Array.from({ length: W < 600 ? 6 : 11 }, () => ({
    s: pick(NOTES), x: R(0, W), y0: R(60, H - 60), vx: pick([-1, 1]) * R(35, 60), ph: R(0, 6.28), amp: R(18, 45), z: Math.round(R(22, 34)), a: R(0.35, 0.7)
  }));
  const squirrels = Array.from({ length: 3 }, (_, k) => ({ x: R(0, W), vx: (k % 2 ? 1 : -1) * R(70, 95), row: k, ph: R(0, 6.28) }));
  const birds = Array.from({ length: 2 }, (_, k) => ({ x: R(0, W), vx: (k % 2 ? -1 : 1) * R(95, 120), y0: H * (0.2 + k * 0.22), ph: R(0, 6.28) }));

  const wrap = (o, w) => { if (o.x > W + w) o.x = -w; else if (o.x < -w) o.x = W + w; };
  const emoji = (ch, x, y, z, vx, sy) => {
    ctx.save(); ctx.translate(x, y); if (vx > 0) ctx.scale(-1, sy || 1); else if (sy) ctx.scale(1, sy);
    ctx.font = z + "px 'Segoe UI Emoji','Apple Color Emoji','Noto Color Emoji',sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText(ch, 0, 0); ctx.restore();
  };
  const birdY = (b, t) => b.y0 + Math.sin(t * 0.8 + b.ph) * H * 0.07;

  function frame(t, dt) {
    ctx.clearRect(0, 0, W, H);
    for (const c of codes) {
      c.x += c.vx * dt; c.y += c.vy * dt; wrap(c, c.w);
      if (c.y > H + 20) c.y = -10; else if (c.y < -20) c.y = H + 10;
      ctx.globalAlpha = c.a; ctx.fillStyle = "rgb(" + c.col + ")"; ctx.font = c.f; ctx.fillText(c.t, c.x, c.y);
    }
    for (const n of notes) {
      n.x += n.vx * dt; wrap(n, 40);
      ctx.globalAlpha = n.a; ctx.fillStyle = "#f6c928";
      ctx.font = n.z + "px 'Segoe UI Symbol','Apple Symbols',serif";
      ctx.fillText(n.s, n.x, n.y0 + Math.sin(t * 0.9 + n.ph) * n.amp);
    }
    for (const q of squirrels) {
      q.x += q.vx * dt; wrap(q, 50);
      ctx.globalAlpha = 0.95;
      emoji("🐿️", q.x, H - 46 - q.row * 20 - Math.abs(Math.sin(t * 5 + q.ph)) * 12, 40, q.vx);
    }
    for (const b of birds) {
      b.x += b.vx * dt; wrap(b, 60);
      for (let k = 6; k >= 1; k--) {
        ctx.globalAlpha = 0.22 / k * 2; ctx.fillStyle = "#f6c928";
        ctx.beginPath(); ctx.arc(b.x - Math.sign(b.vx) * k * 14, birdY(b, t - k * 0.12), 4 - k * 0.4, 0, 6.28); ctx.fill();
      }
      ctx.save(); ctx.globalAlpha = 0.95;
      if ("filter" in ctx) ctx.filter = "brightness(0) drop-shadow(0 0 6px #f6c928)";
      emoji("🦅", b.x, birdY(b, t), 48, b.vx, 1 + Math.sin(t * 7 + b.ph) * 0.12);
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  let last = performance.now(), T = 0;
  function loop(now) {
    const dt = Math.min((now - last) / 1000, 0.05); last = now;
    if (!L.classList.contains("hidden")) { T += dt; frame(T, dt); }
    requestAnimationFrame(loop);
  }
  addEventListener("resize", () => { size(); if (still) frame(0, 0); });
  if (still) frame(0, 0); else requestAnimationFrame(loop);
})();
