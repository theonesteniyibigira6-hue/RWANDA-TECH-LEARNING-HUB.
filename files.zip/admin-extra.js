/* RTLH Admin Control Centre add-on. One line in admin.html, just before </body>:
   <script type="module" src="admin-extra.js"></script>
   Adds managers for library, courses, lessons, opportunities, mentors, teachers, classes, partners,
   sponsors, moderation, users and alerts, a Daily Report, and an admin activity log.
   Every signed-in admin gets identical rights; Firestore/Storage rules are the real security boundary. */
import{getApp,getApps,initializeApp}from"https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import{getAuth}from"https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";
import{getFirestore,collection,getDocs,doc,setDoc,addDoc,updateDoc,deleteDoc,query,limit,serverTimestamp}from"https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";
import{getStorage,ref,uploadBytes,getDownloadURL}from"https://www.gstatic.com/firebasejs/12.1.0/firebase-storage.js";

const CFG=window.RTLH_FIREBASE_CONFIG||{apiKey:"AIzaSyAeye0nqa2XqDKzXObVhGN9D_2EkoReNws",authDomain:"rwanda-tech-learning-hub.firebaseapp.com",projectId:"rwanda-tech-learning-hub",storageBucket:"rwanda-tech-learning-hub.firebasestorage.app",messagingSenderId:"785118659917",appId:"1:785118659917:web:7ada98356d213a3fad2304"};
const app=getApps().length?getApp():initializeApp(CFG),auth=getAuth(app),db=getFirestore(app),sto=getStorage(app);
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const dv=v=>{if(!v)return 0;const d=v.toDate?v.toDate():new Date(v);return d.getTime()||0};
const fmt=v=>{const t=dv(v);return t?new Date(t).toLocaleString():"—"};
const toast=(m,bad)=>{const t=$("#toast");t.textContent=m;t.style.background=bad?"#a32936":"#071a2b";t.classList.remove("hidden");setTimeout(()=>t.classList.add("hidden"),3500)};

/* same intro animation file, loaded automatically */
{const s=document.createElement("script");s.src="admin-intro.js";document.body.appendChild(s)}
/* every admin shows the same role label */
$$(".guardian small").forEach(e=>e.textContent="Super Admin");
{const b=$("#adminBadge");if(b)new MutationObserver(()=>{if(!/^SUPER ADMIN/.test(b.textContent))b.textContent="SUPER ADMIN · AUTHORIZED"}).observe(b,{childList:true,characterData:true,subtree:true})}

const CATS=["Science","Technology","Education","ICT","Mathematics","Languages","Agriculture","Business","Economics","History","Geography","Health","Engineering","Environment","Music","Arts","Teacher Education","Research"];
const LV=["nursery","primary","olevel","alevel","ttc","tvet","professional","adult","bachelor","masters","phd"];
const AR=["academic","technology","trade","life","health","business","science","teacher","arts"];
const ROLES=["superadmin","admin","content_admin","course_admin","library_admin","opportunity_admin","moderator","teacher","mentor","partner","sponsor","student"];
const OT=["Scholarship","Internship","Job","Competition","Fellowship","Volunteering","Grant","Training","Conference","Exchange program"];
const PT=["School","University","NGO","Company","Government","Education organization","Technology organization"];
const oppBadge=r=>{const t=r.deadline?new Date(r.deadline).getTime():0;if(!t)return"";const d=(t-Date.now())/864e5;return d<0?"EXPIRED":d<=7?"CLOSING SOON":"ACTIVE"};

const S=[
{id:"books",ico:"📚",t:"E-Library Manager",d:"Books, covers and PDFs. Files go to Firebase Storage; only details go to Firestore.",c:"books",cols:["title","author","category","access"],flow:["draft","published","archived"],f:[["title","Title","t"],["author","Author","t"],["isbn","ISBN","t"],["publisher","Publisher","t"],["year","Publication year","n"],["language","Language","t"],["category","Category","s",CATS],["domain","Domain","t"],["level","Level","s",LV],["access","Access","s",["Free","Premium"]],["tags","Tags (comma separated)","g"],["description","Description","a"],["pdfUrl","Book PDF","f"],["coverUrl","Cover image","f"],["featured","Featured","b"],["recommended","Recommended","b"],["downloadable","Downloadable","b"]]},
{id:"courses",ico:"🎓",t:"Course Manager",d:"Draft, review, approve, publish and archive courses. Field names match your course catalog.",c:"courses",idf:"id",cols:["title","audience","field","mode","price"],flow:["draft","review","approved","published","archived"],f:[["id","Course ID (short, no spaces)","t"],["title","Title","t"],["audience","Level","s",LV],["field","Area","s",AR],["mode","Mode","s",["Self-paced","E-Class","Live online","Blended"]],["price","Access","s",["Free","Paid","Scholarship"]],["difficulty","Difficulty","s",["Beginner","Intermediate","Advanced","All levels"]],["lessons","Lessons","n"],["weeks","Weeks","n"],["icon","Icon (emoji)","t"],["instructor","Instructor","t"],["desc","Description","a"],["thumbnail","Thumbnail","f"]]},
{id:"lessons",ico:"📖",t:"Lessons & Modules",d:"Module and lesson content for each course (video, PDF, audio or text).",c:"lessons",cols:["courseId","module","title","type"],flow:["draft","published"],f:[["courseId","Course ID","t"],["module","Module","t"],["title","Lesson title","t"],["type","Type","s",["Video","PDF","Audio","Text"]],["url","File (video, PDF or audio)","f"],["order","Order","n"],["content","Text content","a"]]},
{id:"opps",ico:"💼",t:"Opportunities Manager",d:"Scholarships, internships, jobs and more. Closing and expired flags come from the deadline.",c:"opportunities",badge:oppBadge,cols:["title","organization","type","deadline"],flow:["submitted","under_review","approved","published","expired"],f:[["title","Title","t"],["organization","Organization","t"],["type","Type","s",OT],["description","Description","a"],["eligibility","Eligibility","a"],["country","Country","t"],["location","Location","t"],["deadline","Deadline","d"],["startDate","Start date","d"],["endDate","End date","d"],["applyUrl","Application URL","t"],["contact","Contact","t"],["educationLevel","Education level","s",LV],["skills","Required skills","g"],["funding","Funding","t"],["featured","Featured","b"]]},
{id:"mentors",ico:"🧑‍🏫",t:"Mentor Applications",d:"Review and approve mentors.",c:"mentorApplications",cols:["name","expertise","country","email"],flow:["pending","under_review","approved","rejected","suspended"],f:[["name","Name","t"],["email","Email","t"],["country","Country","t"],["expertise","Expertise","t"],["education","Education","t"],["experience","Experience","a"],["languages","Languages","g"],["areas","Areas of mentorship","g"],["availability","Availability","t"],["bio","Biography","a"],["cv","CV","f"],["photo","Profile photo","f"]]},
{id:"teachers",ico:"👨‍🏫",t:"Teacher Verification",d:"Approve or suspend E-Teacher accounts.",c:"teachers",noNew:1,cols:["name","email","country"],flow:["pending","approved","suspended"],f:[]},
{id:"classes",ico:"🏫",t:"E-Class Monitor",d:"Publish, close, archive or suspend E-Classes.",c:"classes",noNew:1,cols:["title","teacherName","level"],flow:["draft","published","closed","archived","suspended"],f:[]},
{id:"partners",ico:"🤝",t:"Partners Manager",d:"Schools, universities, NGOs and companies.",c:"partners",cols:["name","type","country"],flow:["pending","active","ended"],f:[["name","Organization","t"],["type","Partnership type","s",PT],["description","Description","a"],["website","Website","t"],["country","Country","t"],["contact","Contact","t"],["startDate","Start date","d"],["logo","Logo","f"]]},
{id:"sponsors",ico:"🌟",t:"Sponsors Manager",d:"Sponsor profiles and agreements.",c:"sponsors",cols:["name","sponsorshipType","campaign","value"],flow:["pending","active","ended"],f:[["name","Sponsor","t"],["sponsorshipType","Sponsorship type","t"],["campaign","Campaign","t"],["value","Amount / value","t"],["startDate","Start date","d"],["endDate","End date","d"],["visibility","Visibility","s",["Public","Private"]],["logo","Logo","f"]]},
{id:"comments",ico:"💬",t:"Moderation",d:"Review comments. Hidden and spam comments should be ignored by your public pages.",c:"comments",noNew:1,cols:["userName","message","text","createdAt"],flow:["pending","approved","reported","hidden","spam","deleted"],f:[]},
{id:"users",ico:"👥",t:"Users & Roles",d:"Change roles and suspend accounts. Keep the two administrators on role admin or superadmin.",c:"users",noNew:1,sf:"accountStatus",cols:["email","displayName","name","role"],flow:["active","suspended"],ins:[{k:"role",o:ROLES}],f:[]},
{id:"alerts",ico:"🔔",t:"Admin Alerts",d:"Critical, important and information alerts.",c:"adminNotifications",cols:["severity","title","message","createdAt"],flow:["unread","read"],f:[["severity","Severity","s",["critical","important","info"]],["title","Title","t"],["message","Message","a"],["link","Link","t"]]}
];
const sfOf=s=>s.sf||"status";

/* ---------- activity log (adminActivity) ---------- */
async function act(action,type,id,description,metadata){try{const u=auth.currentUser;await addDoc(collection(db,"adminActivity"),{adminId:u?.uid||null,adminEmail:u?.email||null,action,targetType:type,targetId:id||"",description,metadata:metadata||{},timestamp:serverTimestamp(),createdAt:serverTimestamp()})}catch(e){console.warn("activity log",e)}}
async function up(file,folder){const r=ref(sto,folder+"/"+Date.now()+"-"+file.name.replace(/[^\w.-]/g,"_"));await uploadBytes(r,file);return getDownloadURL(r)}

/* ---------- generic manager ---------- */
function cell(v){if(v==null||v==="")return"—";if(Array.isArray(v))return esc(v.join(", "));if(typeof v==="boolean")return v?"✔":"✘";if(v.toDate)return fmt(v);return esc(String(v).slice(0,140))}
function sel(s,x,k,o){const v=x[k]||"";return`<select data-k="${k}" data-id="${esc(x.id)}">${o.includes(v)?"":'<option value="">—</option>'}${o.map(a=>`<option${a===v?" selected":""}>${esc(a)}</option>`).join("")}</select>`}
function draw(s){
 const root=$("#x-"+s.id),q=root.querySelector(".xq").value.toLowerCase(),fs=root.querySelector(".xs").value,sf=sfOf(s);
 const r=(s.rows||[]).filter(x=>(!q||JSON.stringify(x).toLowerCase().includes(q))&&(!fs||String(x[sf]||"").toLowerCase()===fs));
 const ins=[{k:sf,o:s.flow}].concat(s.ins||[]);
 root.querySelector(".xt").innerHTML=r.length?`<table class="table"><thead><tr>${s.cols.map(c=>`<th>${esc(c)}</th>`).join("")}${s.badge?"<th>Flag</th>":""}${ins.map(i=>`<th>${esc(i.k)}</th>`).join("")}<th>Actions</th></tr></thead><tbody>${r.map(x=>`<tr>${s.cols.map(c=>`<td>${cell(x[c])}</td>`).join("")}${s.badge?`<td><span class="pill">${s.badge(x)||"—"}</span></td>`:""}${ins.map(i=>`<td>${sel(s,x,i.k,i.o)}</td>`).join("")}<td>${s.f.length?`<button class="btn" data-a="edit" data-id="${esc(x.id)}">Edit</button> `:""}<button class="btn danger" data-a="del" data-id="${esc(x.id)}">Delete</button></td></tr>`).join("")}</tbody></table>`:'<p class="muted" style="padding:20px;text-align:center">No records found.</p>';
 root.querySelector(".xc").textContent=r.length+" of "+(s.rows||[]).length;
}
async function load(s){const box=$("#x-"+s.id+" .xt");box.textContent="Loading…";try{const g=await getDocs(query(collection(db,s.c),limit(500)));s.rows=g.docs.map(d=>({id:d.id,...d.data()}));draw(s)}catch(e){box.innerHTML=`<div class="alert">Could not read <b>${esc(s.c)}</b>: ${esc(e.message)}<br>Check Firestore rules for the administrator accounts.</div>`}}
function field(f,v){const[k,l,t,o]=f,id="xf-"+k;let h;
 if(t==="a")h=`<textarea id="${id}">${esc(v||"")}</textarea>`;
 else if(t==="s")h=`<select id="${id}"><option value=""></option>${o.map(x=>`<option${x===v?" selected":""}>${esc(x)}</option>`).join("")}</select>`;
 else if(t==="b")h=`<select id="${id}"><option value="false">No</option><option value="true"${v===true?" selected":""}>Yes</option></select>`;
 else if(t==="f")h=`<input id="${id}" type="file">${v?`<small class="muted">Current file: <a href="${esc(v)}" target="_blank" rel="noopener">open</a></small>`:""}`;
 else h=`<input id="${id}" type="${t==="n"?"number":t==="d"?"date":"text"}" value="${esc(t==="g"&&Array.isArray(v)?v.join(", "):v??"")}">`;
 return`<div class="field"><label>${esc(l)}</label>${h}</div>`}
async function val(s,f,row){const[k,,t]=f,e=$("#xf-"+k),v=e.value;
 if(t==="n")return v===""?null:Number(v);if(t==="b")return v==="true";
 if(t==="g")return v.split(",").map(x=>x.trim()).filter(Boolean);
 if(t==="f")return e.files[0]?await up(e.files[0],s.c):(row?.[k]||"");
 return v.trim()}
function form(s,row){
 $("#drawerTitle").textContent=(row?"Edit ":"New ")+s.t;$("#drawerSubtitle").textContent=s.c;
 $("#drawerBody").innerHTML=`<div class="form-grid">${s.f.map(f=>field(f,row?.[f[0]])).join("")}</div><button class="btn primary" id="xSave">Save</button>`;
 $("#recordDrawer").classList.add("open");
 $("#xSave").onclick=async()=>{const b=$("#xSave");b.disabled=true;b.textContent="Saving…";
  try{const d={};for(const f of s.f)d[f[0]]=await val(s,f,row);
   d.updatedAt=serverTimestamp();d.updatedBy=auth.currentUser.email;
   const sf=sfOf(s);let id=row?.id;
   if(row)await updateDoc(doc(db,s.c,id),d);
   else{d.createdAt=serverTimestamp();d.createdBy=auth.currentUser.uid;d[sf]=s.flow[0];
    const cid=s.idf&&String(d[s.idf]||"").trim().replace(/[^\w-]/g,"");
    if(cid){id=cid;await setDoc(doc(db,s.c,id),d)}else id=(await addDoc(collection(db,s.c),d)).id}
   await act(s.id.toUpperCase()+(row?"_UPDATED":"_CREATED"),s.c,id,(row?"Updated ":"Created ")+s.t+": "+(d.title||d.name||id));
   toast("Saved.");$("#recordDrawer").classList.remove("open");load(s)}
  catch(e){toast("Save failed: "+e.message,true);b.disabled=false;b.textContent="Save"}}}
function wire(s){const root=$("#x-"+s.id);
 root.querySelector(".xn").onclick=()=>form(s,null);root.querySelector(".xr").onclick=()=>load(s);
 root.querySelector(".xq").oninput=()=>draw(s);root.querySelector(".xs").onchange=()=>draw(s);
 root.addEventListener("click",async e=>{const b=e.target.closest("[data-a]");if(!b)return;const row=s.rows.find(x=>x.id===b.dataset.id);
  if(b.dataset.a==="edit")form(s,row);
  if(b.dataset.a==="del"&&confirm("Delete "+s.c+"/"+row.id+"?")){try{await deleteDoc(doc(db,s.c,row.id));await act(s.id.toUpperCase()+"_DELETED",s.c,row.id,"Deleted "+(row.title||row.name||row.id));toast("Deleted.");load(s)}catch(err){toast("Delete failed: "+err.message,true)}}});
 root.addEventListener("change",async e=>{const el=e.target.closest("select[data-k]");if(!el)return;const k=el.dataset.k,id=el.dataset.id;
  if(k==="role"&&!confirm("Change this user's role to "+el.value+"?")){load(s);return}
  try{const d={[k]:el.value,updatedAt:serverTimestamp()};if(el.value==="published")d.publishedAt=serverTimestamp();await updateDoc(doc(db,s.c,id),d);await act(s.id.toUpperCase()+"_"+k.toUpperCase()+"_CHANGED",s.c,id,k+" set to "+el.value);toast("Updated.");load(s)}catch(err){toast("Update failed: "+err.message,true);load(s)}})}

/* ---------- daily report ---------- */
const DAILY=[["users","👥 New users"],["courses","🎓 Courses"],["books","📚 Books"],["opportunities","💼 Opportunities"],["enrollments","📝 Enrollments"],["certificates","🏆 Certificates"],["comments","💬 Comments"],["reports","🚩 Reports"],["payments","💳 Payments"],["mentorApplications","🧑‍🏫 Mentor applications"],["partnerApplications","🤝 Partner applications"],["adminActivity","🛡️ Admin actions"]];
const ATT=[["mentorApplications","pending","Mentor applications waiting","mentors"],["teachers","pending","Teachers waiting for verification","teachers"],["courses","review","Courses waiting for review","courses"],["opportunities","submitted","Opportunities waiting for review","opps"],["comments","reported","Reported comments","comments"],["partnerApplications","pending","Partner applications waiting","partners"],["payments","failed","Failed payments",null]];
async function daily(){
 const box=$("#x-daily .xt"),t0=new Date().setHours(0,0,0,0),all={};box.textContent="Loading…";
 await Promise.all([...new Set(DAILY.concat(ATT).map(x=>x[0]))].map(async n=>{try{all[n]=(await getDocs(query(collection(db,n),limit(2000)))).docs.map(d=>d.data())}catch{all[n]=null}}));
 $("#x-daily .xd").textContent=new Date().toLocaleDateString(undefined,{weekday:"long",year:"numeric",month:"long",day:"numeric"});
 const st=r=>String(r.status||"").toLowerCase();
 box.innerHTML=`<div class="stats">${DAILY.map(([n,l])=>{const r=all[n];const today=r?r.filter(x=>dv(x.createdAt||x.timestamp||x.submittedAt)>=t0).length:null;return`<div class="stat"><span>${l}</span><b>${today==null?"—":"+"+today}</b><span>${r?r.length+" total":"no access"}</span></div>`}).join("")}</div>
 <div class="card"><h3>Needs attention</h3>${ATT.map(([n,k,l,go])=>{const c=all[n]?all[n].filter(r=>st(r)===k).length:0;return c?`<div class="notice" style="margin-bottom:8px">${esc(l)}: <b>${c}</b> ${go?`<button class="btn" data-go="${go}">Open</button>`:""}</div>`:""}).join("")||'<p class="muted">Nothing waiting right now.</p>'}</div>`;
 box.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>show(b.dataset.go));
}

/* ---------- mount ---------- */
const meta={daily:["📅","Daily Report","What happened on RTLH today"]};S.forEach(s=>meta[s.id]=[s.ico,s.t,s.d]);
function show(id){
 $$(".view").forEach(v=>v.classList.remove("active"));$("#x-"+id).classList.add("active");
 $$(".navbtn").forEach(b=>b.classList.toggle("active",b.dataset.x===id));
 $("#pageTitle").textContent=meta[id][1];$("#pageSubtitle").textContent=meta[id][2];$("#sidebar").classList.remove("open");scrollTo({top:0});
 id==="daily"?daily():load(S.find(s=>s.id===id))}
function mount(){
 const content=$(".content"),foot=content.querySelector(".footer"),sb=$("#sidebar");
 const mk=(id,inner)=>{const e=document.createElement("section");e.className="view";e.id="x-"+id;e.innerHTML=inner;content.insertBefore(e,foot);return e};
 mk("daily",`<div class="hero"><span class="pill" style="background:rgba(255,255,255,.14);color:#fff">DAILY REPORT</span><h2>What happened on RTLH today?</h2><p class="xd"></p><div class="toolbar"><button class="btn yellow" id="xdr">↻ Refresh</button></div></div><div class="section xt"></div>`);
 $("#xdr").onclick=daily;
 S.forEach(s=>{mk(s.id,`<div class="section-head"><div><h2>${s.ico} ${esc(s.t)}</h2><p class="muted">${esc(s.d)}</p></div><div class="toolbar" style="margin:0">${s.noNew?"":'<button class="btn primary xn">+ Add</button>'}<button class="btn xr">↻ Refresh</button></div></div><div class="card"><div class="searchbar"><input class="xq" placeholder="Search…"><select class="xs" style="width:180px"><option value="">All statuses</option>${s.flow.map(f=>`<option>${f}</option>`).join("")}</select><span class="muted xc" style="align-self:center"></span></div><div class="xt table-wrap"></div></div>`);
  wire(s)});
 const g=document.createElement("div");g.className="nav-group";g.textContent="RTLH Control Centre";
 let a=sb.querySelector(".navbtn");a.after(g);a=g;
 [["daily","📅","Daily Report"],...S.map(s=>[s.id,s.ico,s.t])].forEach(([id,i,t])=>{const b=document.createElement("button");b.className="navbtn";b.dataset.x=id;b.textContent=i+" "+t;b.onclick=()=>show(id);a.after(b);a=b});
 sb.addEventListener("click",e=>{if(e.target.closest("[data-view]"))$$("[data-x]").forEach(b=>b.classList.remove("active"))});
}
const A=$("#adminApp"),go=()=>{if(A&&!A.classList.contains("hidden")&&!window.__rtlhExtra){window.__rtlhExtra=1;mount()}};
if(A){new MutationObserver(go).observe(A,{attributes:true,attributeFilter:["class"]});go()}
